library(readr)
Motosiklet_veri <- read_csv("bikes.csv")
View(Motosiklet_veri)


#VER� SET�NDEN SADECE 2018-2021 ARASINDAK� VER�LER�N ALINMASI


Motosiklet_veri$model_year<- sort(Motosiklet_veri$model_year)
                          
Motosiklet_veri=Motosiklet_veri[-1:-5391, ]
head(Motosiklet_veri)

summary(Motosiklet_veri)
str(Motosiklet_veri)

#KOLON �S�MLER�N�N D�ZELT�LMES�

colnames(Motosiklet_veri) <- c("Model_�smi","Model_Y�l�","KM","Kimden","Konum","Yak�t_ortalamas�","Motor_G�c�","Fiyat")


View(Motosiklet_veri)

Motosiklet_veri$Kimden <- as.factor(Motosiklet_veri$Kimden)

levels(Motosiklet_veri$Kimden) = c("�lk Kullan�c�","�kinci Kullan�c�", "���nc� Kullan�c�", "Dord�nc� Kullan�c� ve dahas�")




#VER� T�P�N� DE���T�RME

install.packages("tidyr")
library(tidyr)

head(Motosiklet_veri)

Motosiklet_veri <- separate(Motosiklet_veri,Yak�t_ortalamas�,c("Yak�t_ortalamas�1","Yak�t_ortalamas�2"))

Motosiklet_veri <- Motosiklet_veri[, -6]

Motosiklet_veri$Yak�t_ortalamas�2=as.numeric(Motosiklet_veri$Yak�t_ortalamas�2)




Motosiklet_veri <- separate(Motosiklet_veri,KM,c("KM1","KM2"), sep = " " )

Motosiklet_veri$KM1=as.numeric(Motosiklet_veri$KM1)

Motosiklet_veri <- Motosiklet_veri[, -4]

Motosiklet_veri <- separate(Motosiklet_veri,Motor_G�c�,c("Motor_G�c�1","Motor_G�c�2"), sep = " " )
Motosiklet_veri$Motor_G�c�1=as.numeric(Motosiklet_veri$Motor_G�c�1)

Motosiklet_veri <- Motosiklet_veri[, -8]


summary(Motosiklet_veri)

#EKS�K VER�LER�N TEM�ZLENMES�

mean(Motosiklet_veri$KM1, na.rm = TRUE)
Motosiklet_veri[is.na(Motosiklet_veri$KM1), "KM1" ] = 21957
is.null(Motosiklet_veri$KM1)

mean(Motosiklet_veri$Yak�t_ortalamas�2, na.rm = TRUE)
Motosiklet_veri[is.na(Motosiklet_veri$Yak�t_ortalamas�2), "Yak�t_ortalamas�2" ] = 45
is.null(Motosiklet_veri$Yak�t_ortalamas�2)

mean(Motosiklet_veri$Motor_G�c�1, na.rm = TRUE)
Motosiklet_veri[is.na(Motosiklet_veri$Motor_G�c�1), "Motor_G�c�1" ] = 21
is.null(Motosiklet_veri$Motor_G�c�1)

#SADECE �K� DE���KEN�N SE��LMES� 

install.packages("tidyverse")
library(tidyverse)

yeni_veri <- select(Motosiklet_veri, Motor_G�c�1, Fiyat)

#AYKIRI DE�ERLER�N BULUNMASI VE �IKARILMASI

plot(x = yeni_veri$Fiyat, y= yeni_veri$Motor_G�c�1, xlab="Fiyat",ylab="Motor_G�c�1",main="Motor_G�c�1 ~ Fiyat")

boxplot(yeni_veri$Motor_G�c�1)


outlier_values <- boxplot.stats(yeni_veri$Motor_G�c�1)$out
outlier_indexes <- which(yeni_veri$Motor_G�c�1 %in% c(outlier_values))
outlier_indexes

reg_veri <- yeni_veri[-outlier_indexes, ]


#VER� G�RSELLE�T�RME

reg_veri <- yeni_veri

boxplot(reg_veri$Motor_G�c�1 , xlab = "Motor_G�c�1")

plot(x = reg_veri$Fiyat, y=reg_veri$Motor_G�c�1, xlab= "Fiyat", ylab="Motor_G�c�1", main="Motor_G�c�1 ~ Fiyat")

hist(reg_veri$Motor_G�c�1, main = "Histogram Motor G�c�", xlab ="Motor_G�c�1")

hist(reg_veri$Fiyat, main = "Histogram Fiyat", xlab = "Fiyat")

reg_veri_n <- reg_veri
plot(reg_veri_n$Fiyat ~ reg_veri_n$Motor_G�c�1, col = "navy")


library(ggplot2)

grafik2=ggplot(reg_veri_n,aes(Fiyat,Motor_G�c�1))
grafik2+geom_smooth()
grafik2+geom_point()

grafik2=ggplot(Motosiklet_veri,aes(Fiyat,Motor_G�c�1))
grafik2+geom_point(aes(size=0, colour = Kimden,shape=Kimden), position = "jitter")


plot(x=Motosiklet_veri$Fiyat,y=Motosiklet_veri$KM1,col="gray")
plot(x=Motosiklet_veri$Fiyat,y=Motosiklet_veri$Model_Y�l�,col="navy blue")
plot(x=reg_veri_n$Fiyat,y=reg_veri_n$Motor_G�c�1,col="navy blue")

#KORELASYON GRAF��� 

install.packages("corrplot")
library(corrplot)
korelasyon_M <- cor(Motosiklet_veri[,c(8,2,7,6,3)])
corrplot(korelasyon_M, method = "color", addCoef.col = "black" , tl.col="black")



korelasyon_n <- cor(reg_veri_n[,c(2,1)])
corrplot(korelasyon_n, method = "pie", addCoef.col = "red", tl.col = "blue")


#KORELASYON VE F�YAT ARALI�ININ BEL�RLENMES�

cor(reg_veri_n)

reg_veri_k <- reg_veri_n[reg_veri_n$Fiyat<500000,]


# REGRESYON MODEL�N� OLU�TURMA
set.seed(1)
egitim_indeksleri <- sample(x = 1:nrow(reg_veri_n), size = 2000, replace = FALSE)

egitim_veri <- as.data.frame(reg_veri_n[egitim_indeksleri,])
test_veri <- as.data.frame(reg_veri_n[-egitim_indeksleri,])

reg_model <- lm(formula = Motor_G�c�1 ~ Fiyat, data = egitim_veri)

print(reg_model)
summary(reg_model)

reg_model$coefficients

plot(x = egitim_veri$Fiyat, y = egitim_veri$Motor_G�c�1, pch = 16, cex = 2.,col = "red", xlab = "Fiyat", ylab = "Motor_G�c�1", main = "Motor_G�c�1 ~ Fiyat")
abline(lm(Motor_G�c�1 ~ Fiyat, data = egitim_veri,))





#MODEL TAHM�N�


model_tahmin <- predict(reg_model, data.frame(Fiyat=test_veri$Fiyat))



head(test_veri$Motor_G�c�1)
head(model_tahmin)

#MODEL TAHM�N�N� MANUEL OLARAK YAPMA

a <- reg_model$coefficients[1]
b <- reg_model$coefficients[2]
yenifiyat <- 150
y <- a+b*yenifiyat
y



#PERFORMANS DE�ERLEND�RME

error <- test_veri$Motor_G�c�1 - model_tahmin
plot(error, pch = 16, col = "red")




#PERFORMAN DE�ERLEND�RME  BA�KA YOL

library(forcats)
forecast::accuracy(object = model_tahmin, test_veri$Motor_G�c�1)
